
function [errorcode, result] = match(stats)

% P = perms(1:size(relativeMapping))
% size(P)
%     for j= 1:size(P)
%
%
%     result=1;
%     end
%

errorcode = 0;
result = [0,0,0,0,0,0,0];
if (size(stats) ~=7)
    errorcode =1;
end


%Map = zeros(size(stats),size(stats));


%myPointsSigs=pointsSigs;
myPointsSigs(7).a=0;
for i= 1:size(stats)
    myPointsSigs(i).a=0;
    myPointsSigs(i).u=0;
    myPointsSigs(i).r=0;
    myPointsSigs(i).l=0;
end
for i= 1:size(stats)
    
    for j= i:size(stats)
        if (i ~=j)
            if (stats(i).Centroid(2) < stats(j).Centroid(2) )    %i higher than j
                myPointsSigs(i).a =   myPointsSigs(i).a+1;
                myPointsSigs(j).u =   myPointsSigs(j).u+1;
                
            elseif (stats(i).Centroid(2) > stats(j).Centroid(2) )    %i lower than j
                myPointsSigs(i).u =   myPointsSigs(i).u+1;
                myPointsSigs(j).a =   myPointsSigs(j).a+1;
            end
            
            
            if (stats(i).Centroid(1) < stats(j).Centroid(1) )    %i left to j
                myPointsSigs(i).l =   myPointsSigs(i).l+1;
                myPointsSigs(j).r =   myPointsSigs(j).r+1;
                
            elseif (stats(i).Centroid(1) > stats(j).Centroid(1) )    %i right to j
                myPointsSigs(i).r =   myPointsSigs(i).r+1;
                myPointsSigs(j).l =   myPointsSigs(j).l+1;
            end
        end
        
        
    end
end
eyebrows = [0,0];
nose=0;
mouth = [0,0,0];
lowerlip=0;

for i= 1:size(stats)
    if (myPointsSigs(i).a >= 5)
        if (eyebrows(1)==0)
            eyebrows(1) = i;
            
        elseif (eyebrows(2)==0)
            eyebrows(2) =i;
        else
            errorcode =2;
        end
    elseif ((myPointsSigs(i).u == 6) )
        if ((lowerlip==0))
            lowerlip= i;
        else
            errorcode=3;
        end
        
    elseif((myPointsSigs(i).u == 2) && (myPointsSigs(i).a == 4))
        if ((nose==0))
            nose= i;
        else
            errorcode=4;
        end
    elseif((myPointsSigs(i).u >= 3))
        % 3 mouth points
        if (mouth(1)==0)
            mouth(1) = i;
        elseif(mouth(2)==0)
            mouth(2) = i;
            
        elseif(mouth(3)==0)
            mouth(3) = i;
            
        else
            errorcode=6;
        end
        
    else
        errorcode =5;
    end
end

if(errorcode==0)
    
    result(3) = nose;
    result(5) = lowerlip;
    if ( stats(eyebrows(1)).Centroid(1) <  stats(eyebrows(2)).Centroid(1))
        result(1) = eyebrows(1);
        result(2) = eyebrows(2);
        
    else
        result(2) = eyebrows(1);
        result(1) = eyebrows(2);
        
    end
    if ( stats(mouth(1)).Centroid(1) <  stats(mouth(2)).Centroid(1) && stats(mouth(1)).Centroid(1) <  stats(mouth(3)).Centroid(1) )
        if ( stats(mouth(2)).Centroid(1) <  stats(mouth(3)).Centroid(1) )
            result(7) = mouth(1);
            result(4) = mouth(2);
            result(6) = mouth(3);
            
        else
            result(7) = mouth(1);
            result(4) = mouth(3);
            result(6) = mouth(2);
            
        end
        
    elseif ( stats(mouth(1)).Centroid(1) >  stats(mouth(2)).Centroid(1) && stats(mouth(1)).Centroid(1) >  stats(mouth(3)).Centroid(1) )
        if ( stats(mouth(2)).Centroid(1) <  stats(mouth(3)).Centroid(1) )
            
            result(7) = mouth(2);
            result(6) = mouth(1);
            result(4) = mouth(3);
            
        else
            result(7) = mouth(3);
            result(6) = mouth(1);
            result(4) = mouth(2);
        end
        
    else
        if ( stats(mouth(2)).Centroid(1) <  stats(mouth(3)).Centroid(1) )
            result(7) = mouth(2);
            result(6) = mouth(3);
            result(4) = mouth(1);
        else
            result(7) = mouth(3);
            result(6) = mouth(2);
            result(4) = mouth(1);
        end
        
    end
    
end
end


