clear;
fh=findall(0,'type','figure');
for i=1:length(fh)
    close(fh(i));
end
mywebcam = webcam;
%mywebcam.AvailableResolutions
mywebcam.Resolution = '320x240';
pause(2);
%preview(mywebcam)
minimum_pixel_size = 10;

context = 30;
totalNumMarker = 7;

type('faceplacement')
loop = true;

Mapping = zeros(7);
% P1 upper left eye brow
% P2 Upper right eyebrow
% P3 Nose
% P4 center upper lip
% P5 center lower lip
% P6 mouth, right
% P7 mouth, left

% 0 NA
% 1 above
% 2 under
% 3 to right of
% 4 to left of

%relative mapping
% Map = [0,4,1,1,1,1,1;
%        3,0,1,1,1,1,1;
%        2,2,0,1,1,1,1;
%        2,2,2,0,1,4,3;
%        2,2,2,2,0,4,3;
%        2,2,2,2,3,0,3;
%        2,2,2,2,4,4,0
%        ];
%
%    %for every point
%    for i= 1:size(Map)
%        pointsSigs(i).a=0;
%        pointsSigs(i).u=0;
%        pointsSigs(i).r=0;
%        pointsSigs(i).l=0;
%
%        for j= 1:size(Map)
%
%            switch (Map(i,j))
%                case 0
%                    break;
%                case 1
%                    pointsSigs(i).a = a+1;
%                    break;
%                case 2
%                    pointsSigs(i).u = u+1;
%
%                    break
%                case 3
%                    pointsSigs(i).r = r+1;
%
%                    break;
%                case 4
%                    pointsSigs(i).l = l+1;
%
%                    break;
%            end
%
%        end
%    end

%nose to upper lip normalization factor



t = tcpip('0.0.0.0', 30000, 'NetworkRole', 'server');
fopen(t);

while(loop)
    
    data = snapshot(mywebcam);
    
    data2=data;
    % data2 = imcomplement(data);
    
    diff_im = imsubtract(data2(:,:,2), rgb2gray(data2));
    diff_im = im2bw(diff_im,0.05);
    diff_im = bwareaopen(diff_im,minimum_pixel_size);
    bw = bwlabel(diff_im, 8);
    stats = regionprops(bw, 'BoundingBox', 'Centroid');
    imshow(data)
    
    hold on
    %
    
    NumberOfMarkers = length(stats);
    for object = 1:length(stats)
        bb = stats(object).BoundingBox;
        bc = stats(object).Centroid;
        [ypos,xpos] = size(diff_im);
        if (bc(2) - context >0 &&  bc(2) + context <ypos && bc(1) - context >0 &&  bc(1) + context <xpos)
            
            rectangle('Position',bb,'EdgeColor','r','LineWidth',2)
            plot(bc(1),bc(2), '-m+')
            a=text(bc(1)+15,bc(2), strcat('X: ', num2str(round(bc(1))), '    Y: ', num2str(round(bc(2)))));
            set(a, 'FontName', 'Arial', 'FontWeight', 'bold', 'FontSize', 12, 'Color', 'yellow');
        else
            NumberOfMarkers =NumberOfMarkers-1 ;
        end
        
    end
    
    
    if(NumberOfMarkers == totalNumMarker)
        [rv, ordering] = match(stats);
        assert(rv==0);
        
        noseToUpperLip=distance(stats(ordering(3)).Centroid, stats(ordering(4)).Centroid);
        noseToREBn= distance(stats(ordering(3)).Centroid, stats(ordering(2)).Centroid)/ noseToUpperLip;
        noseToLEBn=distance(stats(ordering(3)).Centroid, stats(ordering(1)).Centroid)/ noseToUpperLip;
        mouthOpenningn=distance(stats(ordering(4)).Centroid, stats(ordering(5)).Centroid)/ noseToUpperLip;
        mouthOpenningvn=distance(stats(ordering(6)).Centroid, stats(ordering(7)).Centroid)/ noseToUpperLip;
        
        %smile ->mouth openning + low brows
        %surprise->mouth openning + high brows
        %sad -> high brows, no openning
        %frown ->low brows, no openning
        
    end
    
    
    
    
    hold off
    
    
    if(NumberOfMarkers == totalNumMarker)
        
        
        loop = false;
        
    else
        loop=true;
    end
end

figure;


loop = true;
while(loop)
    % Get the snapshot of the current frame
    data = snapshot(mywebcam);
    
    data2=data;
    
    diff_im = imsubtract(data2(:,:,2), rgb2gray(data2));
    
    
    diff_im = im2bw(diff_im,0.05);
    
    
    diff_im = bwareaopen(diff_im,minimum_pixel_size);
    
    bw = bwlabel(diff_im, 8);
    
    stats = regionprops(bw, 'BoundingBox', 'Centroid');
    
    imshow(data)
    
    hold on
    
    
    NumberOfMarkers = length(stats);
    
    for object = 1:length(stats)
        bb = stats(object).BoundingBox;
        bc = stats(object).Centroid;
        
        [ypos,xpos] = size(diff_im);
        if (bc(2) - context >0 &&  bc(2) + context <ypos && bc(1) - context >0 &&  bc(1) + context <xpos)
            
            rectangle('Position',bb,'EdgeColor','r','LineWidth',2)
            plot(bc(1),bc(2), '-m+')
        else
            NumberOfMarkers =NumberOfMarkers-1 ;
        end
        
        
    end
    
    
    if(NumberOfMarkers == totalNumMarker)
        [rv, ordering] = match(stats);
        %ordering
        
        if (rv==0)
            
            for object = 1:NumberOfMarkers
                
                bc = stats(ordering(object)).Centroid; % markercaprt( rtMatching(object,1 )   ).bc;
                a=text(bc(1) +  15   , bc(2)  ,  strcat('P: ', num2str(object))) ;
                set(a, 'FontName', 'Arial', 'FontWeight', 'bold', 'FontSize', 12, 'Color', 'yellow');
                
            end
            
            noseToUpperLiprt=distance(stats(ordering(3)).Centroid, stats(ordering(4)).Centroid);
            noseToREBnrt= distance(stats(ordering(3)).Centroid, stats(ordering(2)).Centroid)/ noseToUpperLiprt;
            noseToLEBnrt=distance(stats(ordering(3)).Centroid, stats(ordering(1)).Centroid)/ noseToUpperLiprt;
            mouthOpenningnrt=distance(stats(ordering(4)).Centroid, stats(ordering(5)).Centroid)/ noseToUpperLiprt;
            mouthOpenningvnrt=distance(stats(ordering(6)).Centroid, stats(ordering(7)).Centroid)/ noseToUpperLiprt;
            
            noseToREBnrtC = noseToREBnrt/noseToREBn;
            noseToLEBnrtC = noseToLEBnrt/noseToLEBn;
            mouthOpenningnrtC = mouthOpenningnrt/mouthOpenningn;
            mouthOpenningvnrtC = mouthOpenningvnrt/mouthOpenningvn;
            
            brows = ( noseToREBnrtC + noseToLEBnrtC)/2;
            brows = brows -1;
            mouthOpen = mouthOpenningnrtC-1;
            mouthOpenV=mouthOpenningvnrtC-1
            
            smile = 0; surprise=0;frown=0;sad=0;
            if ( mouthOpen  - 0.05 >0)
                if (mouthOpenV >0)
                    smile = 2*mouthOpenV
                    fwrite(t,'s');
                    fwrite(t,smile*255);
                    
                    
                else
                    surprise = 2*mouthOpen
                    fwrite(t,'r');
                    fwrite(t,surprise*255);
                    
                end
            else
                
                if ( brows<0)
                    frown = (0-10)*brows
                    
                    fwrite(t,'f');
                    fwrite(t,frown*255);
                    
                else
                    sad = 10*brows
                    fwrite(t,'a');
                    fwrite(t,sad*255);
                    
                end
            end
       
            
        end
    end
    hold off
    
    % loop=false;
end


pause(2);
fh=findall(0,'type','figure');
for i=1:length(fh)
    close(fh(i));
end